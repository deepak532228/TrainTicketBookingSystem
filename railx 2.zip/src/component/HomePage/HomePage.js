import React from "react";
import { Link, useHistory } from "react-router-dom";
import LoginNavbar from "../LoginNavbar/LoginNavbar";
import Header from "./Header";
import "./HomePage.css";
import { useLocation, useNavigate } from "react-router-dom";

function HomePage() {
  const user = localStorage.getItem("user");
  const navigate = useNavigate();


  return (
    <div className="home">
      
      {user ? <LoginNavbar /> : <Header />}
      <div className="wel">
      <h1>Welcome To RailX...</h1>
      <p>Welcome back! Ready to embark on a new journey?</p>
      <button type="button" onClick={() => (user ? navigate("/createBooking") : navigate("/searchTrain"))}>
        Search Train
      </button>
      </div>
      <div className="trainimage">
        
      </div>
    </div>
  );
}

export default HomePage;