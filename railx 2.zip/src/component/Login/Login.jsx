import React, { useState } from "react";
import axios from "axios";
import { useLocation, useNavigate } from "react-router-dom";
import "./Login.css";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const location = useLocation();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post('http://localhost:8080/user/getlogin', { username, password })
      .then((res) => {
        console.log(res);
        if (res.data && res.data.id) {
          // save user data in local storage or state and navigate to home page
          localStorage.setItem("user", JSON.stringify(res.data));
          const user = JSON.parse(localStorage.getItem("user"));
          if (user.role === "Admin") {
            alert("Admin Login Successful")
            navigate('/viewTrain');
          } else {
            const train = location.state && location.state.train;
            alert("User Login Successful");
            if (train) {
              // navigate to the createBooking page with the train object as state
              console.log("Train object:", train);
              navigate('/createBooking', { state: { train } });
            } else {
              // navigate to the home page
              navigate('/searchTrain');
            }
          }
        } else {
          alert("Invalid username or password");
        }
      })
      .catch((error) => {
        console.error('There was an error!', error);
      });
  }

  return (
    <div>
      <h1>Login</h1>
      <div className='login'>
        <form onSubmit={handleSubmit}>
          <label>
            Username:
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </label>
          <label>
            Password:
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <p>
              Don't have an account?{" "}
              <span
                onClick={() => navigate('/signup')}
                style={{ color: "blue", cursor: "pointer" }}
              >
                Register
              </span>
            </p>
          </label>
          <button type="submit">Login</button>
        </form>
      </div>
    </div>
  );
}

export default Login;