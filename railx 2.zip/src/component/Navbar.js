import React from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Navbar() {
  const navigate = useNavigate();
  function onAddTrain() {
    navigate("/addTrain");
  }
  function onViewTrain() {
    navigate("/viewTrain");
  }
  function onHomePage() {
    navigate("/home");
  }
  function onSearchTrain() {
    navigate("/searchTrain");
  }

  return (
    <div>
      <div className="button-container">
        <nav>
        
        </nav>
       
        <button onClick={onHomePage} className="home-button">
          Home
        </button>
        <button onClick={onAddTrain} className="add-button">
          Add Train
        </button>
        <button onClick={onViewTrain} className="view-button">
          View Train
        </button>
        <button onClick={onSearchTrain} className="search-button">
          Search Train
        </button>

        {/* <button onClick={onAddTrain} className="update-button" onClick={() => handleUpdate(selectedTrain?.trainId)} disabled={!selectedTrain}>Update Train</button>
                <button onClick={onAddTrain} className="delete-button" onClick={() => handleDelete(selectedTrain?.trainId)} disabled={!selectedTrain}>Delete Train</button> */}
      </div>
    </div>
  );
}
