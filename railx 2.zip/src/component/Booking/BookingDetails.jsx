import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './BookingDetails.css';
import LoginNavbar from '../LoginNavbar/LoginNavbar';

const BookingDetails = () => {
  const [booking, setBooking] = useState(null);
  const [bookingIdFromStorage, setBookingIdFromStorage] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const bookingString = localStorage.getItem('booking');
    console.log(bookingString);

    let booking = {};
    if (bookingString) {
      booking = JSON.parse(bookingString);
      console.log(booking.bookingId);
      setBookingIdFromStorage(booking.bookingId);
    }
  }, []);

  useEffect(() => {
    if (bookingIdFromStorage) {
const fetchBooking = async () => {
        try {
          const response = await axios.get(`http://localhost:8080/bookings/${bookingIdFromStorage}`);
          setBooking(response.data);
        } catch (error) {
          console.error('Error fetching booking:', error);
        }
      };

      fetchBooking();
    }
  }, [bookingIdFromStorage]);

  if (!booking) {
    return <p>Loading booking details...</p>;
  }

  const bookingId = booking.bookingId; // Extract bookingId from booking object

  return (
    <div>
      <LoginNavbar/>
      <h2>Booking Details</h2>
      <table className='bookingd'>
        <thead>
          <tr>
            {/* <th>Booking ID</th>
            <th>Train ID</th> */}
            <th>Train Name</th>
            <th>Source</th>
            <th>Destination</th>
            <th>Train Type</th>
            <th>Journey Date</th>
            <th>Arrival Time</th>
            <th>Departure Time</th>
            <th>Available Seats</th>
            <th>Fare</th>
            <th>Total Tickets</th>
            <th>Total Fare</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            {/* <td>{bookingId}</td>
            <td>{booking.train.trainId}</td> */}
            <td>{booking.train.trainName}</td>
            <td>{booking.train.source}</td>
            <td>{booking.train.destination}</td>
            <td>{booking.train.trainType}</td>
            <td>{booking.train.journeyDate}</td>
            <td>{booking.train.arrivalTime}</td>
            <td>{booking.train.departureTime}</td>
            <td>{booking.train.availableSeats}</td>
            <td>{booking.train.fare}</td>
            <td>{booking.totalTickets}</td>
            <td>{booking.totalFare}</td>
          </tr>
        </tbody>
      </table>
      <button className='confirmbutton' onClick={() => navigate("/generateTicket")}>Confirm Booking</button>
    </div>
  );
};

export default BookingDetails;