import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Signup.css';

function Signup() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("User");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8080/user/create', { username, password, role:'User' })
      .then((res) => {
        console.log(res);
        alert("Registered successfully");
        navigate('/login');
      })
      .catch((error) => {
        console.error('There was an error!', error);
      });
  }

  return (
    <div>
      <h1>Signup</h1>
      <div className='Signup'>
      <form onSubmit={handleSubmit}>
        <label>
          Username:
          <input className='username' type="text" value={username} onChange={(e) => setUsername(e.target.value)} required/>
        </label>
        <label>
          Password:
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required/>
        </label>
        <label>
          Role:
          <input className='role' type="text" value={role} onChange={(e) => setRole(e.target.value)} required/>
        </label>
        <button type="submit">Sign Up</button>
      </form>
    </div>
    </div>

  );
};

export default Signup;

 