import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import './ViewTicket.css'; // Import the CSS file

const ViewTicket = () => {
  const [ticket, setTicket] = useState(null);
  const { state } = useLocation();

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    const booking = JSON.parse(localStorage.getItem('booking'));

    if (user && booking) {
      const userId = user.id;
      const bookingId = booking.bookingId;

      axios.get(`http://localhost:8080/ticket/getByUserAndBookingId/${userId}/${bookingId}`)
        .then(response => {
          setTicket(response.data[0]);
        })
        .catch(error => console.error('Error fetching ticket:', error));
    }
  }, []);

  return (
    <div className="railway-ticket">
      {ticket ? (
        <div>
          <h2>Ticket</h2>
          {/* <button className="print-btn" onClick={() => window.print()}>Print Ticket</button> */}
          <table className='viewtick'>
            <tbody>
              <tr>
                <td>Booking ID:</td>
                <td>{ticket.bookingId}</td>
              </tr>
              <tr>
                <td>Train Name:</td>
                <td>{ticket.train.trainName}</td>
              </tr>
              <tr>
                <td>Train Type:</td>
                <td>{ticket.train.trainType}</td>
              </tr>
              <tr>
                <td>Source:</td>
                <td>{ticket.train.source}</td>
              </tr>
              <tr>
                <td>Destination:</td>
                <td>{ticket.train.destination}</td>
              </tr>
              <tr>
                <td>Journey Date:</td>
                <td>{ticket.train.journeyDate}</td>
              </tr>
              <tr>
                <td>Arrival Time:</td>
                <td>{ticket.train.arrivalTime}</td>
              </tr>
              <tr>
                <td>Departure Time:</td>
                <td>{ticket.train.departureTime}</td>
              </tr>
              <tr>
                <td>Total Tickets:</td>
                <td>{ticket.totalTickets}</td>
              </tr>
              <tr>
              <td><strong>Total Fare:</strong> (Rs.)</td>
                <td><strong>{ticket.totalFare}</strong></td>
              </tr>
            </tbody>
          </table>
          <h3>Passenger Details:</h3>
          <ul>
            {ticket.passengerDetails.map(passenger => (
              <li key={passenger.id}>
                Name: {passenger.name} | Age: {passenger.age} | Gender: {passenger.gender}
              </li>
            ))}
          </ul>
          <div className="total-fare">
            Status: Reserved
          </div>
          <button className="print-btn" onClick={() => window.print()}>Print Ticket</button>
        </div>
        
      ) : (
        <p>Loading ticket information...</p>
      )}
    </div>
  );
};

export default ViewTicket;