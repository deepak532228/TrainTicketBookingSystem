import React, { useState } from "react";
import axios from "axios";
import "./SearchTrain.css";

import LoginNavbar from '../LoginNavbar/LoginNavbar';
import { useNavigate } from 'react-router-dom';
import Header from "../HomePage/Header";

const SearchTrain = () => {
  const [form, setForm] = useState({
    source: "",
    destination: "",
    journeyDate: "",
  });

  const [trains, setTrains] = useState([]);

  const navigate = useNavigate();

  const handleInputChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform search using the form values
    const { source, destination, journeyDate } = form;
    // You can use axios to make a request to your API
    axios
      .get(
        `http://localhost:8080/train/${source}/${destination}/${journeyDate}`
      )
      .then((response) => {
        setTrains(response.data);
      })
      .catch((error) => {
        console.error("Error fetching train data: ", error);
      });
  };
  const [showDiv, setShowDiv] = useState(false);

  const handleBookClick = (train) => {
    localStorage.setItem("train", JSON.stringify(train));
  
    // Check if user is logged in
    if (localStorage.getItem("user")) {
      // User is logged in, navigate to createBooking
      navigate("/createBooking", { state: { train } });
    } else {
      // User is not logged in, navigate to login
      navigate("/login", { state: { train } });
    }
  };

  // Check if user object exists in local storage
  const user = localStorage.getItem("user");

  return (
    <>
      {user ? (
        <>
        <LoginNavbar/> 
        <div className="searchTrain">
            <form className="train-search-form" onSubmit={handleSubmit}>
              <div className="searchtrain">
                <div className="d-flex items-center justify-between">
                  <div className="flex-item border-1-custom p-2 rounded-md w-full mx-1">
                    <fieldset >
                      <legend className="font-weight-bold px-2 text-lg">From</legend>
                      <input
                        type="text"
                        placeholder="Where from"
                        name="source"
                        value={form.source}
                        onChange={handleInputChange}
                        className='rounded p-1 lg:min-w-40 w-full transitionall duration-300 focus:outline-0 focus:bg-gray-200 font-medium' 
                      />
                    </fieldset>
                  </div>
                  <div className="flex-item border-1-custom p-2 rounded-md w-full mx-1">
                    <fieldset title="To">
                      <legend className="font-bold px-2 text-lg">To</legend>
                      <input
                        type="text"
                        placeholder="Where to"
                        name="destination"
                        value={form.destination}
                        onChange={handleInputChange}
                        className='rounded p-1 lg:min-w-40 w-full transitionall duration-300 focus:outline-0 focus:bg-gray-200 font-medium' 
                      />
                    </fieldset>
                  </div>
                  <div className="flex-item border-1-custom p-2 rounded-md w-full mx-1">
                    <fieldset title="Date">
                      <legend className="font-bold px-2 text-lg">Select Date</legend>
                      <input
                        type="Date"
                        name="journeyDate"
                        value={form.journeyDate}
                        onChange={handleInputChange}
                        className='rounded p-1 lg:min-w-40 w-full transitionall duration-300 focus:outline-0 focus:bg-gray-200 font-medium' 
                      />
                    </fieldset>
                  </div>
                </div>
                <button  type="submit" className="searchbutton" onClick={() => setShowDiv(!showDiv)}>Search</button>
              </div>
            </form>{showDiv && (
              <table className="train-table">
                <thead>
                  <tr>
                    <th>Train ID</th>
                    <th>Train Name</th>
                    <th>Train Type</th>
                    <th>Source</th>
                    <th>Destination</th>
                    <th>Journey Date</th>
                    <th>Arrival Time</th>
                    <th>Departure Time</th>
                    <th>Fare (Rs.)</th>
                    <th>Available Seats</th>
                    <th>Total Seats</th>
                    <th>Book</th>
                  </tr>
                </thead>
                <tbody>
                  {trains.map((train) => (
                    <tr key={train.trainId}>
                      <td>{train.trainId}</td>
                      <td>{train.trainName}</td>
                      <td>{train.trainType}</td>
                      <td>{train.source}</td>
                      <td>{train.destination}</td>
                      <td>{train.journeyDate}</td>
                      <td>{train.arrivalTime}</td>
                      <td>{train.departureTime}</td>
                      <td>{train.fare}</td>
                      <td>{train.availableSeats}</td>
                      <td>{train.totalSeats} </td>
                      <td>
                        <button type="submit" className="book-button" onClick={() => handleBookClick(train)}>
                          Book
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      ) : (
        <>
          <Header />
          <div className="searchTrain">
            <form className="train-search-form" onSubmit={handleSubmit}>
              <div className="searchtrain">
                <div className="d-flex items-center justify-between">
                  <div className="flex-item border-1-custom p-2 rounded-md w-full mx-1">
                    <fieldset >
                      <legend className="font-weight-bold px-2 text-lg">From</legend>
                      <input
                        type="text"
                        placeholder="Where from"
                        name="source"
                        value={form.source}
                        onChange={handleInputChange}
                        className='rounded p-1 lg:min-w-40 w-full transitionall duration-300 focus:outline-0 focus:bg-gray-200 font-medium' 
                      />
                    </fieldset>
                  </div>
                  <div className="flex-item border-1-custom p-2 rounded-md w-full mx-1">
                    <fieldset title="To">
                      <legend className="font-bold px-2 text-lg">To</legend>
                      <input
                        type="text"
                        placeholder="Where to"
                        name="destination"
                        value={form.destination}
                        onChange={handleInputChange}
                        className='rounded p-1 lg:min-w-40 w-full transitionall duration-300 focus:outline-0 focus:bg-gray-200 font-medium' 
                      />
                    </fieldset>
                  </div>
                  <div className="flex-item border-1-custom p-2 rounded-md w-full mx-1">
                    <fieldset title="Date">
                      <legend className="font-bold px-2 text-lg">Select Date</legend>
                      <input
                        type="Date"
                        name="journeyDate"
                        value={form.journeyDate}
                        onChange={handleInputChange}
                        className='rounded p-1 lg:min-w-40 w-full transitionall duration-300 focus:outline-0 focus:bg-gray-200 font-medium' 
                      />
                    </fieldset>
                  </div>
                </div>
                <button  type="submit" className="searchbutton" onClick={() => setShowDiv(!showDiv)}>Search</button>
              </div>
            </form>{showDiv && (
              <table className="train-table">
                <thead>
                  <tr>
                    <th>Train ID</th>
                    <th>Train Name</th>
                    <th>Train Type</th>
                    <th>Source</th>
                    <th>Destination</th>
                    <th>Journey Date</th>
                    <th>Arrival Time</th>
                    <th>Departure Time</th>
                    <th>Fare (Rs.)</th>
                    <th>Available Seats</th>
                    <th>Total Seats</th>
                    <th>Book</th>
                  </tr>
                </thead>
                <tbody>
                  {trains.map((train) => (
                    <tr key={train.trainId}>
                      <td>{train.trainId}</td>
                      <td>{train.trainName}</td>
                      <td>{train.trainType}</td>
                      <td>{train.source}</td>
                      <td>{train.destination}</td>
                      <td>{train.journeyDate}</td>
                      <td>{train.arrivalTime}</td>
                      <td>{train.departureTime}</td>
                      <td>{train.fare}</td>
                      <td>{train.availableSeats}</td>
                      <td>{train.totalSeats} </td>
                      <td>
                        <button type="submit" className="book-button" onClick={() => handleBookClick(train)}>
                          Book
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}
    </>
  );
};

export default SearchTrain;