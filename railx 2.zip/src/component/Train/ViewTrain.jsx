import './ViewTrain.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Navbar from '../Navbar';
import AdminLoginNavbar from '../LoginNavbar/AdminNavbar';


function ViewTrain() {
    const [trainData, setTrainData] = useState([]);
    const [selectedTrain, setSelectedTrain] = useState(null);
    const navigate = useNavigate();
    useEffect(() => {
        allTrains();
    }, []);
    const allTrains = () => {
        axios.get('http://localhost:8080/train/all')
            .then(res => {
                setTrainData(res.data);
            })
            .catch(err => {
                console.log(err);
            });
    }
    const handleDelete = (trainId) => {
        console.log(trainId);
        axios.delete(`http://localhost:8080/train/delete/${trainId}`)
            .then(res => {
                setTrainData(trainData.filter(train => train.id !== trainId));
                alert("Train deleted successfully");
                allTrains();
            })
            .catch(err => {
                console.log(err);
                alert("Error deleting train");
            });

    }

    const handleUpdate = (trainId) => {
        const trainToUpdate = trainData.find(train => train.trainId === trainId);
        setSelectedTrain(trainToUpdate);

    }

    const handleSave = () => {
        axios.put(`http://localhost:8080/train/update`, selectedTrain)
            .then(res => {
                setTrainData(trainData.map(train => train.trainId === selectedTrain.trainId ? selectedTrain : train));
                setSelectedTrain(null);
                alert("Train updated successfully");
            })
            .catch(err => {
                console.log(err);
                alert("Error updating train");
            });
    }
    function onAddTrain() {
        navigate('/addTrain');
    }

    const handleSelect = (id, value) => {
        <Navbar/>
        if (value === 'update') {
            handleUpdate(id);
        } else if (value === 'delete') {
            
            handleDelete(id);
        }
    };
    return (
        <>
            <AdminLoginNavbar/>

            <h1></h1>

            {!selectedTrain && (
                <table>
                    <thead>
                        <tr>
                            <th>Train Id</th>
                            <th>Train Name</th>
                            <th>Train Type</th>
                            <th>Source</th>
                            <th>Destination</th>
                            <th>Journey Date</th>
                            <th>Arrival Time</th>
                            <th>Departure Time</th>
                            <th>Fare</th>
                            <th>Available Seats</th>
                            <th>Total Seats</th>
                        </tr>
                    </thead>
                    <tbody>
                        {trainData.map((train, index) => (
                            <tr key={index}>
                                <td>{train.trainId}</td>
                                <td>{train.trainName}</td>
                                <td>{train.trainType}</td>
                                <td>{train.source}</td>
                                <td>{train.destination}</td>
                                <td>{train.journeyDate}</td>
                                <td>{train.arrivalTime}</td>
                                <td>{train.departureTime}</td>
                                <td>{train.fare}</td>
                                <td>{train.availableSeats}</td>
                                <td>{train.totalSeats}</td>
                                <td>
                                    <select onChange={(event) => handleSelect(train.trainId, event.target.value)}>
                                        <option>Action</option>
                                        <option value="update">Update</option>
                                        <option value="delete">Delete</option>
                                    </select>
                                </td>

                                {/* <td><button value={train.trainId} onClick={() => handleUpdate(train.trainId)}>Update</button></td>

                                <td><button onClick={() => handleDelete(train.trainId)}>Delete</button></td> */}
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}

            {selectedTrain && (
                <>
                
                    <h1>Update Train Details</h1>
                    <form>
                        <label htmlFor="trainName">Train Name:</label>
                        <input type="text" id="trainName" name="trainName" value={selectedTrain.trainName} onChange={(e) => setSelectedTrain({ ...selectedTrain, trainName: e.target.value })} /><br /><br />


                        <label htmlFor="train_type">Train Type:</label>
                        <select id="train_type" value={selectedTrain.trainType} onChange={(e) => setSelectedTrain({ ...selectedTrain, trainType: e.target.value })} >
                            <option value="Select Type" disabled>Select Type</option>
                            <option value="AC" >AC</option>
                            <option value="Sleeper">Sleeper</option>

                        </select><br /><br />

                        <label htmlFor="source">Source:</label>
                        <input type="text" id="source" name="source" value={selectedTrain.source} onChange={(e) => setSelectedTrain({ ...selectedTrain, source: e.target.value })} /><br /><br />

                        <label htmlFor="destination">Destination:</label>
                        <input type="text" id="destination" name="destination" value={selectedTrain.destination} onChange={(e) => setSelectedTrain({ ...selectedTrain, destination: e.target.value })} /><br /><br />

                        <label htmlFor="journeyDate">Journey Date:</label>
                        <input type="date" name="trainJourneyDate" value={selectedTrain.journeyDate} onChange={(e) => setSelectedTrain({ ...selectedTrain, journeyDate: e.target.value })} /><br /><br />


                        <label htmlFor="arrival_time">Arrival Time:</label>
                        <input type="time" id="arrival_time" name="arrival_time" value={selectedTrain.arrivalTime} onChange={(e) => setSelectedTrain({ ...selectedTrain, arrivalTime: e.target.value })} /><br /><br />

                        <label htmlFor="departure_time">Departure Time:</label>
                        <input type="time" id="departure_time" name="departure_time" value={selectedTrain.departureTime} onChange={(e) => setSelectedTrain({ ...selectedTrain, departureTime: e.target.value })} /><br /><br />


                        <label htmlFor="fare">Fare:</label>
                        <input type="number" id="fare" name="fare" value={selectedTrain.fare} onChange={(e) => setSelectedTrain({ ...selectedTrain, fare: e.target.value })} /><br /><br />

                        <label htmlFor="seat">Available Seats:</label>
                        <input type="number" id="availableSeats" name="availableSeats" value={selectedTrain.availableSeats} onChange={(e) => setSelectedTrain({ ...selectedTrain, availableSeats: e.target.value })} /><br /><br />

                        <label htmlFor="totalSeats">Total Seats:</label>
                        <input type="number" id="totalSeats" name="totalSeats" min="0" value={selectedTrain.totalSeats} onChange={(e) => setSelectedTrain({ ...selectedTrain, totalSeats: e.target.value })} /><br /><br />

                        <button type="submit" onClick={handleSave}>Save Train</button>
                    </form>
                </>
            )}
        </>
    );
}

export default ViewTrain;