import React, { useState, useEffect } from 'react';
import axios from 'axios';
import PassengerList from './PassengerList'; // Import the PassengerList component
import { useNavigate } from 'react-router-dom'; // Import useNavigate hook
import AdminLoginNavbar from '../LoginNavbar/AdminNavbar';

function Bookings() {
  const [trains, setTrains] = useState([]);
  const navigate = useNavigate(); // Initialize useNavigate hook

  useEffect(() => {
    const fetchTrains = async () => {
      try {
        const response = await axios.get('http://localhost:8080/train/all');
        setTrains(response.data);
      } catch (error) {
        console.error('Error fetching trains:', error);
      }
    };

    fetchTrains();
  }, []);

  const handleShowBookings = async trainId => {
    try {
      const response = await axios.get(`http://localhost:8080/ticket/getByTrainId/${trainId}`);
      // Pass the selected train data as props to the PassengerList page
      const selectedTrain = trains.find(train => train.trainId === trainId);
      const path = `/passengerList/${trainId}`;
      navigate(path, { state: { selectedTrain } }); // Use navigate instead of this.props.history.push
    } catch (error) {
      console.error('Error fetching bookings:', error);
    }
  };

  return (
    <div>
       <AdminLoginNavbar/>
      <h1>Trains</h1>
      <table>
        <thead>
          <tr>
            <th>Train ID</th>
            <th>Train Name</th>
            <th>Train Type</th>
            <th>Source</th>
            <th>Destination</th>
            <th>Journey Date</th>
            <th>Arrival Time</th>
            <th>Departure Time</th>
            <th>Fare</th>
            <th>Available Seats</th>
            <th>Total Seats</th>
            <th>Total Bookings</th>
          </tr>
        </thead>
        <tbody>
          {trains.map(train => (
            <tr key={train.trainId}>
              <td>{train.trainId}</td>
              <td>{train.trainName}</td>
              <td>{train.trainType}</td>
              <td>{train.source}</td>
              <td>{train.destination}</td>
              <td>{train.journeyDate}</td>
              <td>{train.arrivalTime}</td>
              <td>{train.departureTime}</td>
              <td>{train.fare}</td>
              <td>{train.availableSeats}</td>
              <td>{train.totalSeats}</td>
              <td>
                <button onClick={() => handleShowBookings(train.trainId)}>
                  Show Bookings
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Bookings;